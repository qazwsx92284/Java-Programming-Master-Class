package com.company;

public class Vehicle {

    private String type;
    private int speed;
    private int engine;

    public Vehicle(String type, int speed, int engine) {
        this.type = type;
        this.speed = speed;
        this.engine = engine;
    }

    public void move(int speed) {
        this.speed = speed;
        System.out.println("Vehicle.move() called");
        System.out.println("moving at " + speed);
    }

    public void stop(){
        this.speed = 0;
        System.out.println("Vehicle.stop() called. Current speed : " + this.speed);
    }

    public void startEngine() {
        System.out.println("Vehicle.startEngine() called");
    }

    public void stopEngine() {
        System.out.println("Vehicle.stopEngine() caleed");
    }

}
