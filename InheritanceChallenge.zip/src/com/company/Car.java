package com.company;

public class Car extends Vehicle {
    private String brand;
    private int wheels;
    private String type;


    public Car(int speed, String brand, int wheels, String type1) {
        super("car",speed, 1);
        this.brand = brand;
        this.wheels = wheels;
        this.type = type1;
    }

    public void move() {
        System.out.println("car.move() called");
    }

    @Override
    public void move(int speed) {
        super.move(speed);
    }

    @Override
    public void stop() {
        super.stop();
    }

    @Override
    public void startEngine() {
        super.startEngine();
    }

    @Override
    public void stopEngine() {
        super.stopEngine();
    }

}
