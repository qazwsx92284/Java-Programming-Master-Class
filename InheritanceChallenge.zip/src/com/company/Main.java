package com.company;

public class Main {

    public static void main(String[] args) {

        Mercedes m1 = new Mercedes("E350" , "n",0,0,false );

        m1.startEngine();
        m1.move();
        m1.move(10);
        m1.increaseSpeed(3);
        System.out.println(m1.getGear());
        m1.changeGear("D");
        m1.increaseSpeed(4);
        m1.setBrake(true);
        m1.decreaseSpeed(3);
        m1.isParked();
        m1.changeGear("p");
        m1.isParked();


    }
}
