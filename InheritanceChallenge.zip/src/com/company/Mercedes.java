package com.company;

public class Mercedes extends Car{
    private String name;
    private String gear;
    private int speed;
    private int accel;
    private boolean brake;

    public Mercedes(String name, String gear, int speed, int accel, boolean brake) {
        super(0, "Mercedes", 4, "car");
        this.name = name;
        this.gear = gear;
        this.speed = speed;
        this.accel = accel;
        this.brake = brake;
    }
    public void increaseSpeed(int accel) {
        if(this.gear.equalsIgnoreCase("D")){
            super.move();
            this.accel = accel;
            this.speed += accel;
            super.move(this.speed);
            System.out.println("Mercedes.increaseSpeed called");
            System.out.println("accelerate " + accel + ". Current speed : " + speed);
        }
        else {
            System.out.println("Unable. Change gear.");
        }

    }

    public void decreaseSpeed(int accel) {
        if(this.brake == true) {
            super.move();
            this.accel = accel;
            this.speed -= accel;
            super.move(this.speed);
            System.out.println("Mercedes.increaseSpeed called");
            System.out.println("accelerate " + accel + ". Current speed : " + speed);
            if(speed-accel<0) {
                System.out.println("Car stopped");
            }
        }
        else {
            System.out.println("Invalid. Change brake to true");
        }
    }

    public void isParked() {
        if(this.gear.equalsIgnoreCase("P")){
            System.out.println("Is Parked");
        } else {
            System.out.println("Is Not Parked");
        }
    }

    public void direction() {
        if(gear.equalsIgnoreCase("r")){
            System.out.println("gear is R. moving backward ");
        }
        if(speed<0) {
            System.out.println("moving backward at speed of" + (-speed));
        }
    }

    public void changeGear(String gear) {
        this.gear = gear;
    }

    public void setBrake(boolean brake) {
        this.brake = brake;
    }
    public boolean getBrake() {
        return brake;
    }
    public String getName() {
        return name;
    }

    public String getGear() {
        return gear;
    }

    public int getSpeed() {
        return speed;
    }

    public int getAccel() {
        return accel;
    }

    @Override
    public void move() {
        super.move();
    }

    @Override
    public void move(int speed) {
        super.move(speed);
    }

    @Override
    public void stop() {
        super.stop();
    }

    @Override
    public void startEngine() {
        super.startEngine();
    }

    @Override
    public void stopEngine() {
        super.stopEngine();
    }
}
